package com.example.cardgame;

import java.util.ArrayList;
import java.util.List;

public class Game {
    private List<Player> players;
    private int currentRoundIndex; // 0 to 15
    private int dealerIndex; // Index in players list

    public Game() {
        this.players = new ArrayList<>();
        this.currentRoundIndex = 0;
        this.dealerIndex = 0;
    }

    public void addPlayer(String name) {
        players.add(new Player(name));
    }

    public List<Player> getPlayers() {
        return players;
    }

    public int getPlayerCount() {
        return players.size();
    }

    // Round logic: 1..8, 8, 7..1
    // Rounds 0-7: 1 to 8 cards
    // Round 8: 8 cards
    // Rounds 9-15: 7 to 1 cards
    public int getCardsForRound(int roundIndex) {
        if (roundIndex < 8) {
            return roundIndex + 1;
        } else if (roundIndex == 8) {
            return 8;
        } else {
            // roundIndex 9 -> 7 cards
            // roundIndex 15 -> 1 card
            // 8 - (roundIndex - 8) = 16 - roundIndex
            return 16 - roundIndex;
        }
    }

    public int getCurrentRoundCards() {
        return getCardsForRound(currentRoundIndex);
    }

    public int getCurrentRoundIndex() {
        return currentRoundIndex;
    }
    
    public int getTotalRounds() {
        return 16;
    }

    public boolean isLastRound() {
        return currentRoundIndex == 15;
    }
    
    public Player getDealer() {
        if (players.isEmpty()) return null;
        return players.get(dealerIndex);
    }

    public void setDealerIndex(int index) {
        this.dealerIndex = index;
    }
    
    public int getDealerIndex() {
        return dealerIndex;
    }

    // Returns the list of players in order starting from the one to the right of the dealer
    // In many card games, play moves clockwise (left). But prompt says "para la derecha del que reparte"
    // Usually "derecha" means the next person in sequence.
    // If dealer is i, next is (i+1)%n.
    public List<Player> getBiddingOrder() {
        List<Player> ordered = new ArrayList<>();
        int count = players.size();
        if (count == 0) return ordered;
        
        for (int i = 1; i <= count; i++) {
            int index = (dealerIndex + i) % count;
            ordered.add(players.get(index));
        }
        return ordered;
    }

    // Validation for dealer's bid
    // Dealer is the last one in the bidding order.
    // sumOfBids + dealerBid != totalCards
    public boolean isValidBid(Player player, int bid, int currentSumOfOtherBids) {
        int cards = getCurrentRoundCards();
        if (bid < 0 || bid > cards) return false;

        if (player == getDealer()) {
            if (bid + currentSumOfOtherBids == cards) {
                return false;
            }
        }
        return true;
    }

    public void finishRound() {
        int cards = getCurrentRoundCards();
        boolean isDoubled = (cards == 1) && isLastRound(); // Only last round (16) is doubled, which has 1 card.
        // There is also round 1 which has 1 card, but prompt says "solo queda la ultima ronda con 1 carta ... puntos son duplicados"

        for (Player p : players) {
            int points = 0;
            // 1 point per trick
            points += p.getCurrentTricks();
            
            // 3 points bonus if bid met
            if (p.getCurrentTricks() == p.getCurrentBid()) {
                points += 3;
            }
            
            if (isDoubled) {
                points *= 2;
            }
            
            p.addScore(points);
        }

        // Advance round
        currentRoundIndex++;
        // Advance dealer
        dealerIndex = (dealerIndex + 1) % players.size();
    }
    
    public boolean isGameOver() {
        return currentRoundIndex >= 16;
    }
    
    public Player getWinner() {
        Player winner = null;
        int maxScore = Integer.MIN_VALUE;
        for (Player p : players) {
            if (p.getScore() > maxScore) {
                maxScore = p.getScore();
                winner = p;
            }
        }
        return winner;
    }
}
