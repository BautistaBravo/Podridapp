package com.example.cardgame;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GameActivity extends AppCompatActivity {

    private Game game;
    private TextView infoTextView;
    private LinearLayout inputsContainer;
    private Button actionButton;
    private List<EditText> inputFields;
    private List<Player> currentOrder;

    private enum State {
        BIDDING,
        RESULTS
    }

    private State currentState;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        infoTextView = findViewById(R.id.tv_game_info);
        inputsContainer = findViewById(R.id.inputs_container);
        actionButton = findViewById(R.id.btn_action);
        inputFields = new ArrayList<>();

        ArrayList<String> names = getIntent().getStringArrayListExtra("PLAYER_NAMES");
        if (names == null) {
            finish();
            return;
        }

        game = new Game();
        for (String name : names) {
            game.addPlayer(name);
        }

        startRound();
    }

    private void startRound() {
        if (game.isGameOver()) {
            goToResults();
            return;
        }

        currentState = State.BIDDING;
        updateUI();
    }

    private void updateUI() {
        inputsContainer.removeAllViews();
        inputFields.clear();

        int roundNum = game.getCurrentRoundIndex() + 1;
        int cards = game.getCurrentRoundCards();
        Player dealer = game.getDealer();

        StringBuilder info = new StringBuilder();
        info.append("Ronda ").append(roundNum).append("\n");
        info.append("Cartas: ").append(cards).append("\n");
        info.append("Reparte: ").append(dealer.getName()).append("\n\n");

        if (currentState == State.BIDDING) {
            info.append("Ingrese Apuestas (orden desde derecha del repartidor):");
            actionButton.setText("Confirmar Apuestas");
            currentOrder = game.getBiddingOrder();
        } else {
            info.append("Ingrese Manos Ganadas:");
            actionButton.setText("Confirmar Resultados");
            // For results, usually we just list players in standard order or same order.
            // Let's use standard player list order to make it easier to match with paper if they have it.
            // Or use the same bidding order. Let's use bidding order for consistency.
            currentOrder = game.getBiddingOrder();
        }

        infoTextView.setText(info.toString());

        for (Player p : currentOrder) {
            TextView label = new TextView(this);
            label.setText(p.getName() + " (Puntaje: " + p.getScore() + ")");
            inputsContainer.addView(label);

            EditText input = new EditText(this);
            input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
            if (currentState == State.BIDDING) {
                input.setHint("Apuesta (0-" + cards + ")");
            } else {
                input.setHint("Manos ganadas (Apostó: " + p.getCurrentBid() + ")");
            }
            inputsContainer.addView(input);
            inputFields.add(input);
        }
        
        actionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentState == State.BIDDING) {
                    processBids();
                } else {
                    processResults();
                }
            }
        });
    }

    private void processBids() {
        int sumBids = 0;
        int cards = game.getCurrentRoundCards();
        boolean valid = true;

        // First pass: validation
        for (int i = 0; i < currentOrder.size(); i++) {
            Player p = currentOrder.get(i);
            String text = inputFields.get(i).getText().toString();
            if (text.isEmpty()) {
                inputFields.get(i).setError("Ingrese valor");
                return;
            }
            int bid = Integer.parseInt(text);
            
            // Check range
            if (bid < 0 || bid > cards) {
                inputFields.get(i).setError("Debe ser entre 0 y " + cards);
                valid = false;
            }

            // Dealer constraint check (last player in currentOrder)
            if (i == currentOrder.size() - 1) {
                // This is the dealer
                 if (!game.isValidBid(p, bid, sumBids)) {
                     inputFields.get(i).setError("El repartidor no puede apostar para sumar " + cards);
                     valid = false;
                 }
            }
            sumBids += bid;
        }

        if (!valid) return;

        // Apply bids
        for (int i = 0; i < currentOrder.size(); i++) {
            int bid = Integer.parseInt(inputFields.get(i).getText().toString());
            currentOrder.get(i).setCurrentBid(bid);
        }

        currentState = State.RESULTS;
        updateUI();
    }

    private void processResults() {
        int sumTricks = 0;
        int cards = game.getCurrentRoundCards();
        
        for (int i = 0; i < currentOrder.size(); i++) {
            String text = inputFields.get(i).getText().toString();
            if (text.isEmpty()) {
                inputFields.get(i).setError("Ingrese valor");
                return;
            }
            int tricks = Integer.parseInt(text);
             if (tricks < 0) {
                inputFields.get(i).setError("Positivo");
                return;
            }
            sumTricks += tricks;
        }

        if (sumTricks != cards) {
            Toast.makeText(this, "La suma de manos (" + sumTricks + ") debe ser igual a cartas (" + cards + ")", Toast.LENGTH_LONG).show();
            return;
        }

        // Apply tricks
        for (int i = 0; i < currentOrder.size(); i++) {
            int tricks = Integer.parseInt(inputFields.get(i).getText().toString());
            currentOrder.get(i).setCurrentTricks(tricks);
        }

        game.finishRound();
        startRound();
    }

    private void goToResults() {
        Intent intent = new Intent(this, ResultActivity.class);
        // Pass scores strings
        ArrayList<String> results = new ArrayList<>();
        Player winner = game.getWinner();
        results.add("GANADOR: " + (winner != null ? winner.getName() : "Nadie"));
        
        for (Player p : game.getPlayers()) {
            results.add(p.getName() + ": " + p.getScore());
        }
        
        intent.putStringArrayListExtra("RESULTS", results);
        startActivity(intent);
        finish();
    }
}
