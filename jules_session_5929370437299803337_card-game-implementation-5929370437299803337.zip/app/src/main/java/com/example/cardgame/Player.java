package com.example.cardgame;

public class Player {
    private String name;
    private int score;
    private int currentBid;
    private int currentTricks;

    public Player(String name) {
        this.name = name;
        this.score = 0;
    }

    public String getName() {
        return name;
    }

    public int getScore() {
        return score;
    }

    public void addScore(int points) {
        this.score += points;
    }

    public int getCurrentBid() {
        return currentBid;
    }

    public void setCurrentBid(int currentBid) {
        this.currentBid = currentBid;
    }

    public int getCurrentTricks() {
        return currentTricks;
    }

    public void setCurrentTricks(int currentTricks) {
        this.currentTricks = currentTricks;
    }
}
