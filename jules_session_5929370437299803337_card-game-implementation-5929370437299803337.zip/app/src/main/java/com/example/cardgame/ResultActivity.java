package com.example.cardgame;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class ResultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 32, 32, 32);
        
        ArrayList<String> results = getIntent().getStringArrayListExtra("RESULTS");
        if (results != null) {
            for (String line : results) {
                TextView tv = new TextView(this);
                tv.setText(line);
                tv.setTextSize(24);
                layout.addView(tv);
            }
        }
        
        Button btnRestart = new Button(this);
        btnRestart.setText("Volver al Inicio");
        btnRestart.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 Intent intent = new Intent(ResultActivity.this, MainActivity.class);
                 intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                 startActivity(intent);
                 finish();
             }
        });
        layout.addView(btnRestart);

        setContentView(layout);
    }
}
