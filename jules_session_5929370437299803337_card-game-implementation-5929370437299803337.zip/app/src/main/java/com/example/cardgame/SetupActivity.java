package com.example.cardgame;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class SetupActivity extends AppCompatActivity {

    private LinearLayout playersContainer;
    private ArrayList<EditText> playerInputs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setup);

        playersContainer = findViewById(R.id.players_container);
        playerInputs = new ArrayList<>();

        // Add 4 default fields for convenience
        addPlayerField();
        addPlayerField();
        addPlayerField();
        addPlayerField();

        Button addPlayerButton = findViewById(R.id.btn_add_player);
        addPlayerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addPlayerField();
            }
        });

        Button finishSetupButton = findViewById(R.id.btn_finish_setup);
        finishSetupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ArrayList<String> names = new ArrayList<>();
                for (EditText input : playerInputs) {
                    String name = input.getText().toString().trim();
                    if (!name.isEmpty()) {
                        names.add(name);
                    }
                }

                if (names.size() < 2) {
                    Toast.makeText(SetupActivity.this, "Ingrese al menos 2 jugadores", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Pass names to GameActivity
                Intent intent = new Intent(SetupActivity.this, GameActivity.class);
                intent.putStringArrayListExtra("PLAYER_NAMES", names);
                startActivity(intent);
            }
        });
    }

    private void addPlayerField() {
        EditText editText = new EditText(this);
        editText.setHint("Nombre del jugador");
        playerInputs.add(editText);
        playersContainer.addView(editText);
    }
}
